#include <iostream>

using namespace std;

#include "tlistacom.h"

void pruebaTLista1(){

	  TComplejo a(1);

	  TListaCom l1;
	  l1.InsCabeza(a);

	  TListaCom l2(l1),l3(l2);

	  cout<<"l1 = "<<l1<<endl;
	  cout<<"l2 = "<<l2<<endl;
	  cout<<"l3 = "<<l3<<endl;

}

void pruebaTLista2(){
	  TComplejo a;
	  TListaCom l1,l2;

	  l1.InsCabeza(a);

	  if(l1 == l2)
	    cout << "SI" << endl;
	  else
	    cout << "NO" << endl;

	  if(l1 != l2)
	    cout << "SI" << endl;
	  else
	    cout << "NO" << endl;

}

void pruebaTLista3(){
	  TComplejo a, b(1), c(2, 3);
	  TListaCom l1;

	  l1.InsCabeza(a);
	  l1.InsertarI(b, l1.Ultima());
	  l1.InsertarD(c, l1.Primera());

	  cout<<"l1 = "<<l1<<endl;
}

void pruebaTLista4(){
	  TComplejo a(-3, -3);
	  TListaCom l1;
	  TListaPos p1;

	  if(l1.EsVacia())
	    cout << "VACIA" << endl;
	  else
	    cout << "NO VACIA" << endl;

	  l1.InsCabeza(a);
	  p1=l1.Ultima();

	  if(l1.EsVacia())
	    cout << "VACIA" << endl;
	  else
	    cout<<l1.Obtener(p1)<<endl;
}

void pruebaTLista5(){
	  TComplejo a, b(1), c(2, 3), d(3,4);
	  TListaCom l1,l2,l3;

	  l1.InsCabeza(a);
	  l1.InsertarD(b, l1.Ultima());
	  l2.InsCabeza(c);
	  l2.InsertarI(d, l2.Primera());

	  l3=l1+l2;
	  cout<<"l3 = "<<l3<<endl;
}

void pruebaTLista6(){
	  TComplejo a, b(1), c(2, 3), d(3,4);
	  TListaCom l1,l2,l3;

	  l1.InsCabeza(a);
	  l1.InsertarD(b, l1.Ultima());
	  l2.InsCabeza(c);
	  l2.InsertarI(b, l2.Primera());

	  l3=l1-l2;
	  cout<<"l3 = "<<l3<<endl;
}

void pruebaTLista7(){
	  TComplejo a, b(1), c(2, 3), d(b);
	  TListaCom l1;

	  l1.InsCabeza(a);
	  l1.InsCabeza(b);
	  l1.InsCabeza(c);
	  l1.InsCabeza(d);
	  l1.BorrarTodos(d);

	  cout<<"l1 = "<<l1<<endl;
}

void pruebaTLista8(){
	  TComplejo a(-3, -3), b;
	  TListaCom l1;

	  for (int i=0; i<10; i++) {
	         a = a + double(i);
	         l1.InsCabeza(a);
	  }
	  cout<<l1.Longitud()<<endl;
	  if (l1.Buscar(a)) cout<<"Encontrado c"<<endl;
	  else cout<<"No encontrado c"<<endl;
	  if (l1.Buscar(b)) cout<<"Encontrado b"<<endl;
	  else cout<<"No encontrado c"<<endl;
}

void pruebaTListaN1(){

	TComplejo a, b, c;
	TListaCom d, e, f;

	cout << "No hace nada" << endl;


}
void pruebaTListaN2(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a, b, c;

	cout << a.Longitud() << endl;
	cout << b.Longitud() << endl;
	cout << c.Longitud() << endl;

	a.InsCabeza(p);
	b.InsCabeza(p);
	b.InsertarD(q,b.Ultima());
	c.InsCabeza(p);
	c.InsertarD(q,c.Ultima());
	c.InsertarD(r,c.Ultima());

	cout << a.Longitud() << endl;
	cout << b.Longitud() << endl;
	cout << c.Longitud() << endl;

}
void pruebaTListaN3(){

	TListaCom a;

	cout << a << endl;

}
void pruebaTListaN4(){

	TComplejo p(1, 2);
	TListaCom a, b;

	if (a == b) {
		cout << "SI" << endl;
	} else {
		cout << "NO" << endl;
	}
	a.InsCabeza(p);

	if (a == b) {
		cout << "SI" << endl;
	} else {
		cout << "NO" << endl;
	}

}
void pruebaTListaN5(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarI(r,a.Ultima());

	cout << a << endl;

}
void pruebaTListaN6(){

	TComplejo p(1, 2);
	TListaCom a, b;

	a.InsCabeza(p);
	b = a;

	cout << a << endl;
	cout << b << endl;

}
void pruebaTListaN7(){

	TComplejo p(1, 2);
	TListaCom a;

	cout << "Longitud: " << a.Longitud() << endl;

	a.InsCabeza(p);
	cout << "Longitud: " << a.Longitud() << endl;

	a.InsertarD(p,a.Ultima());
	cout << "Longitud: " << a.Longitud() << endl;

	a.~TListaCom();
	cout << "Longitud: " << a.Longitud() << endl;

}
void pruebaTListaN8(){

	TComplejo p(1, 2);
	TListaCom a, b;

	cout << "Longitud: " << a.Longitud() << endl;
	cout << "Longitud: " << b.Longitud() << endl;

	a.InsCabeza(p);
	b = a;

	cout << "Longitud: " << a.Longitud() << endl;
	cout << "Longitud: " << b.Longitud() << endl;

}
void pruebaTListaN9(){

	TComplejo p(1, 1), q(2, 2);
	TListaCom a;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	cout << a << endl;

	a.Borrar(p);
	cout << a << endl;

	a.Borrar(q);
	cout << a << endl;

}
void pruebaTListaN10(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());

	if (a.Buscar(p)) {
		cout << "SI" << endl;
	} else {
		cout << "NO" << endl;
	}
	if (a.Buscar(q)) {
		cout << "SI" << endl;
	} else {
		cout << "NO" << endl;
	}
	if (a.Buscar(r)) {
		cout << "SI" << endl;
	} else {
		cout << "NO" << endl;
	}

}

void pruebaTListaN11(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;
	TListaPos pos;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());

	pos = a.Primera();

	while (!pos.EsVacia()) {
		cout << a.Obtener(pos) << endl;
		pos = pos.Siguiente();
	}

}

void pruebaTListaN12(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;
	TListaPos pos;

	a.InsCabeza(p);
	a.InsertarI(q,a.Ultima());
	a.InsertarI(r,a.Ultima());

	pos = a.Ultima();

	while (!pos.EsVacia()) {
		cout << a.Obtener(pos) << endl;
		pos = pos.Anterior();
	}

}

void pruebaTListaN13(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;
	TListaPos pos;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());

	pos = a.Ultima();
	a.Borrar(pos);

	pos = a.Ultima();
	a.Borrar(pos);

	pos = a.Ultima();
	a.Borrar(pos);

	cout << a << endl;

}

void pruebaTListaN14(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;
	TListaPos pos;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());

	pos = a.Primera();
	a.Borrar(pos);

	pos = a.Primera();
	a.Borrar(pos);

	pos = a.Primera();
	a.Borrar(pos);

	cout << a << endl;

}

void pruebaTListaN15(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a, b;

	a.InsCabeza(p);
	b.InsCabeza(r);
	b.InsertarD(q,b.Ultima());

	cout << a + b << endl;

}

void pruebaTListaN16(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a, b;

	a.InsCabeza(p);

	b.InsCabeza(r);
	b.InsertarD(q,b.Ultima());
	b.InsertarD(p,b.Ultima());

	cout << a - b << endl;

}

void pruebaTListaN17(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a, b;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	b.InsCabeza(r);
	b.InsertarD(q,b.Ultima());

	cout << a - b << endl;

}

void pruebaTListaN18(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a,b;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarD(q,a.Ultima());
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());
	a.InsertarD(r,a.Ultima());

	b = a;

	cout << a << endl;
	cout << b << endl;
}

void pruebaTListaN19(){

	TListaCom a;
	TListaCom b(a);
	TListaCom c;

	cout << a << endl;
	cout << b << endl;
	cout << c << endl;
	a.~TListaCom();
	b.~TListaCom();
	cout << a << endl;
	cout << b << endl;
	c.InsCabeza(TComplejo());
	cout << c << endl;
	c.~TListaCom();
	cout << c << endl;

}

void pruebaTListaN20(){

	TListaCom a;
	TListaCom b;

	a.InsCabeza(TComplejo());
	b = a;
	cout << a << endl;
	cout << b << endl;

}

void pruebaTListaN21(){

	TListaCom a;
	TListaCom b;

	if (a == b) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}
	a.InsCabeza(TComplejo());
	if (a == b) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	b = a;
	if (a == b) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}
	b.InsertarD(TComplejo(),b.Ultima());
	if (a == b) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	a.InsertarD(TComplejo(1, 1),a.Ultima());
	if (a == b) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}

}

void pruebaTListaN22(){

	TListaCom a;
	TListaCom b;
	TListaCom c;

	a.InsCabeza(TComplejo(1, 1));
	a.InsertarD(TComplejo(2, 2),a.Ultima());
	b.InsCabeza(TComplejo(1, 1));
	b.InsertarD(TComplejo(2, 2),b.Ultima());
	cout << a + b << endl;
	b.InsertarD(TComplejo(3, 3),b.Ultima());
	b.InsertarD(TComplejo(4, 4),b.Ultima());
	b.InsertarD(TComplejo(5, 5),b.Ultima());
	cout << a + b << endl;
	cout << a + c << endl;

}

void pruebaTListaN23(){

	TListaCom a;
	TListaCom b;
	TListaCom c;

	a.InsCabeza(TComplejo(1, 1));
	a.InsertarD(TComplejo(2, 2),a.Ultima());
	b.InsCabeza(TComplejo(1, 1));
	b.InsertarD(TComplejo(2, 2),b.Ultima());
	cout << a - b << endl;
	b.InsertarD(TComplejo(3, 3),b.Ultima());
	b.InsertarD(TComplejo(4, 4),b.Ultima());
	b.InsertarD(TComplejo(5, 5),b.Ultima());
	cout << a - b << endl;
	cout << a - c << endl;
	c.InsCabeza(TComplejo(1, 1));
	c.InsertarD(TComplejo(4, 4),c.Ultima());
	c.InsertarD(TComplejo(5, 5),c.Ultima());
	cout << a - c << endl;

}

void pruebaTListaN24(){

	TListaCom a;

	if (a.EsVacia()) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}
	a.InsCabeza(TComplejo());
	if (a.EsVacia()) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	a.Borrar(TComplejo());
	if (a.EsVacia()) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}
	a.InsCabeza(TComplejo(1, 1));
	if (a.EsVacia()) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	a.Borrar(TComplejo());
	if (a.EsVacia()) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}

}

void pruebaTListaN25(){

	TListaCom a;
	TListaCom b;
	TListaCom c;
	TListaCom d;

	cout << a << endl;
	a.InsCabeza(TComplejo(1, 1));
	cout << a << endl;
	a.InsertarD(TComplejo(2, 2),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(3, 3),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(4, 4),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(5, 5),a.Ultima());
	cout << a << endl;

	cout << b << endl;
	b.InsCabeza(TComplejo(5, 5));
	cout << b << endl;
	b.InsertarD(TComplejo(4, 4),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(3, 3),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(2, 2),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(1, 1),b.Ultima());
	cout << b << endl;

	cout << c << endl;
	c.InsCabeza(TComplejo(3, 3));
	cout << c << endl;
	c.InsertarD(TComplejo(2, 2),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(4, 4),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(1, 1),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(5, 5),c.Ultima());
	cout << c << endl;

	if (d.InsCabeza(TComplejo())) {
		cout << "CORRECTO" << endl;
		cout << c << endl;
	} else {
		cout << "INCORRECTO" << endl;
		cout << c << endl;
	}
	if (d.InsertarD(TComplejo(),d.Ultima())) {
		cout << "CORRECTO" << endl;
		cout << c << endl;

	} else {
		cout << "INCORRECTO" << endl;
		cout << c << endl;
	}
	if (d.InsertarD(TComplejo(1, 1),d.Ultima())) {
		cout << "CORRECTO" << endl;
		cout << c << endl;
	} else {
		cout << "INCORRECTO" << endl;
		cout << c << endl;
	}
	if (d.InsertarD(TComplejo(1, 1),d.Ultima())) {
		cout << "CORRECTO" << endl;
		cout << c << endl;
	} else {
		cout << "INCORRECTO" << endl;
		cout << c << endl;
	}

}

void pruebaTListaN26(){

	TListaCom a;
	TListaCom b;
	TListaCom c;
	TListaCom d;
	TListaCom e;
	TListaPos p, q;

	cout << a << endl;
	a.InsCabeza(TComplejo(1, 1));
	cout << a << endl;
	a.InsertarD(TComplejo(2, 2),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(3, 3),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(4, 4),a.Ultima());
	cout << a << endl;
	a.InsertarD(TComplejo(5, 5),a.Ultima());
	cout << a << endl;

	cout << b << endl;
	b.InsCabeza(TComplejo(5, 5));
	cout << b << endl;
	b.InsertarD(TComplejo(4, 4),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(3, 3),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(2, 2),b.Ultima());
	cout << b << endl;
	b.InsertarD(TComplejo(1, 1),b.Ultima());
	cout << b << endl;

	cout << c << endl;
	c.InsCabeza(TComplejo(3, 3));
	cout << c << endl;
	c.InsertarD(TComplejo(2, 2),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(4, 4),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(1, 1),c.Ultima());
	cout << c << endl;
	c.InsertarD(TComplejo(5, 5),c.Ultima());
	cout << c << endl;

	cout << a << endl;
	a.Borrar(TComplejo(1, 1));
	cout << a << endl;
	a.Borrar(TComplejo(2, 2));
	cout << a << endl;
	a.Borrar(TComplejo(4, 4));
	cout << a << endl;
	a.Borrar(TComplejo(5, 5));
	cout << a << endl;

	cout << b << endl;
	b.Borrar(TComplejo(5, 5));
	cout << b << endl;
	b.Borrar(TComplejo(1, 1));
	cout << b << endl;
	b.Borrar(TComplejo(3, 3));
	cout << b << endl;

	p = c.Primera();
	q = c.Ultima();

	cout << c << endl;
	c.Borrar(p);
	cout << c << endl;
	c.Borrar(q);
	cout << c << endl;

	p = c.Primera();
	q = c.Ultima();

	c.Borrar(p);
	cout << c << endl;
	c.Borrar(q);
	cout << c << endl;

	if (a.Borrar(TComplejo(10, 10))) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	if (e.Borrar(TComplejo(10, 10))) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	p = a.Primera();
	if (a.Borrar(p)) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}
	q = a.Ultima();
	if (a.Borrar(q)) {
		cout << "INCORRECTO" << endl;
	} else {
		cout << "CORRECTO" << endl;
	}
	a.InsCabeza(TComplejo());
	p = a.Primera();
	if (a.Borrar(p)) {
		cout << "CORRECTO" << endl;
	} else {
		cout << "INCORRECTO" << endl;
	}

}

void pruebaTListaN27(){

	TListaCom a;
	TListaPos p, q;

	a.InsCabeza(TComplejo(1, 1));
	a.InsertarI(TComplejo(2, 2),a.Primera());
	a.InsertarI(TComplejo(3, 3),a.Primera());

	p = a.Primera();
	q = a.Ultima();
	cout << a.Obtener(p) << endl;
	cout << a.Obtener(q) << endl;

}

void pruebaTListaN28(){

	TListaCom a;

		a.InsCabeza(TComplejo());
		a.InsertarD(TComplejo(1, 1),a.Ultima());
		a.InsertarD(TComplejo(2, 2),a.Ultima());
		a.InsertarD(TComplejo(3, 3),a.Ultima());
		a.InsertarD(TComplejo(4, 4),a.Ultima());
		a.InsertarD(TComplejo(5, 5),a.Ultima());

		if (a.Buscar(TComplejo())) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}
		if (a.Buscar(TComplejo(1, 1))) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}
		if (a.Buscar(TComplejo(2, 2))) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}

		if (a.Buscar(TComplejo(3, 3))) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}

		if (a.Buscar(TComplejo(4, 4))) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}

		if (a.Buscar(TComplejo(5, 5))) {
			cout << "CORRECTO" << endl;
		} else {
			cout << "INCORRECTO" << endl;
		}
		if (a.Buscar(TComplejo(6, 6))) {
			cout << "INCORRECTO" << endl;
		} else {
			cout << "CORRECTO" << endl;
		}

}

void pruebaTListaN29(){

	TComplejo p(1, 1), q(2, 2), r(3, 3);
	TListaCom a;

	cout << a.Longitud() << endl;
	a.InsCabeza(p);
	cout << a.Longitud() << endl;
	a.InsertarD(q,a.Ultima());
	cout << a.Longitud() << endl;
	a.InsertarD(r,a.Ultima());
	cout << a.Longitud() << endl;

}

void pruebaTListaN30(){

	TComplejo p(1, 1),q(2,2);
	TListaCom a;

	a.InsCabeza(q);
	a.InsertarD(p,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(q,a.Ultima());//8 TCOMPLEJO

	a.Borrar(p);

	cout << a << endl;

	a.BorrarTodos(p);

	cout << a << endl;

}

void pruebaTListaN31(){

	TComplejo p(1, 1),q(2,2),r(3,3),s(4,4),t(5,5);
	TListaCom a;

	a.InsCabeza(p);
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());
	a.InsertarD(s,a.Ultima());
	a.InsertarD(t,a.Ultima());
	a.InsertarD(p,a.Ultima());
	a.InsertarD(q,a.Ultima());
	a.InsertarD(r,a.Ultima());//8 TCOMPLEJO

	cout << a << endl;
	a.Borrar(r);
	cout << a << endl;
	a.Borrar(r);
	cout << a << endl;



}

int
main(void)
{

	cout << "PRUEBAS LISTA" << endl;
	cout << "PRUEBAS LISTA" << endl;
	cout << "PRUEBAS LISTA" << endl;
	cout << "PRUEBAS LISTA" << endl;
	cout << "PRUEBAS LISTA" << endl;

	cout << endl;

	cout << "Prueba TLista1" << endl;
	pruebaTLista1();
	cout << endl;
	cout << "Prueba TLista2" << endl;
	pruebaTLista2();
	cout << endl;
	cout << "Prueba TLista3" << endl;
	pruebaTLista3();
	cout << endl;
	cout << "Prueba TLista4" << endl;
	pruebaTLista4();
	cout << endl;
	cout << "Prueba TLista5" << endl;
	pruebaTLista5();
	cout << endl;
	cout << "Prueba TLista6" << endl;
	pruebaTLista6();
	cout << endl;
	cout << "Prueba TLista7" << endl;
	pruebaTLista7();
	cout << endl;
	cout << "Prueba TLista8" << endl;
	pruebaTLista8();
	cout << endl;

	cout << "Prueba TListaN1" << endl;
	pruebaTListaN1();
	cout << endl;
	cout << "Prueba TListaN2" << endl;
	pruebaTListaN2();
	cout << endl;
	cout << "Prueba TListaN3" << endl;
	pruebaTListaN3();
	cout << endl;
	cout << "Prueba TListaN4" << endl;
	pruebaTListaN4();
	cout << endl;
	cout << "Prueba TListaN5" << endl;
	pruebaTListaN5();
	cout << endl;
	cout << "Prueba TListaN6" << endl;
	pruebaTListaN6();
	cout << endl;
	cout << "Prueba TListaN7" << endl;
	pruebaTListaN7();
	cout << endl;
	cout << "Prueba TListaN8" << endl;
	pruebaTListaN8();
	cout << endl;
	cout << "Prueba TListaN9" << endl;
	pruebaTListaN9();
	cout << endl;
	cout << "Prueba TListaN10" << endl;
	pruebaTListaN10();
	cout << endl;
	cout << "Prueba TListaN11" << endl;
	pruebaTListaN11();
	cout << endl;
	cout << "Prueba TListaN12" << endl;
	pruebaTListaN12();
	cout << endl;
	cout << "Prueba TListaN13" << endl;
	pruebaTListaN13();
	cout << endl;
	cout << "Prueba TListaN14" << endl;
	pruebaTListaN14();
	cout << endl;
	cout << "Prueba TListaN15" << endl;
	pruebaTListaN15();
	cout << endl;
	cout << "Prueba TListaN16" << endl;
	pruebaTListaN16();
	cout << endl;
	cout << "Prueba TListaN17" << endl;
	pruebaTListaN17();
	cout << endl;
	cout << "Prueba TListaN18" << endl;
	pruebaTListaN18();
	cout << endl;
	cout << "Prueba TListaN19" << endl;
	pruebaTListaN19();
	cout << endl;
	cout << "Prueba TListaN20" << endl;
	pruebaTListaN20();
	cout << endl;
	cout << "Prueba TListaN21" << endl;
	pruebaTListaN21();
	cout << endl;
	cout << "Prueba TListaN22" << endl;
	pruebaTListaN22();
	cout << endl;
	cout << "Prueba TListaN23" << endl;
	pruebaTListaN23();
	cout << endl;
	cout << "Prueba TListaN24" << endl;
	pruebaTListaN24();
	cout << endl;
	cout << "Prueba TListaN25" << endl;
	pruebaTListaN25();
	cout << endl;
	cout << "Prueba TListaN26" << endl;
	pruebaTListaN26();
	cout << endl;
	cout << "Prueba TListaN27" << endl;
	pruebaTListaN27();
	cout << endl;
	cout << "Prueba TListaN28" << endl;
	pruebaTListaN28();
	cout << endl;
	cout << "Prueba TListaN29" << endl;
	pruebaTListaN29();
	cout << endl;
	cout << "Prueba TListaN30" << endl;
	pruebaTListaN30();
	cout << endl;
	cout << "Prueba TListaN31" << endl;
	pruebaTListaN31();
	cout << endl;

	  return 0;
}


